package com.quantiphi.examples.aws.ec2.examples;


import java.util.ArrayList;
import java.util.List;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.DescribeInstancesRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.EbsInstanceBlockDevice;
import com.amazonaws.services.ec2.model.GroupIdentifier;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceBlockDeviceMapping;
import com.amazonaws.services.ec2.model.InstanceNetworkInterface;
import com.amazonaws.services.ec2.model.ProductCode;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.Tag;


public class DescribeInstance {

	private static String secretKey = "";
	private static String accessKey = "";
	private static Regions regions = Regions.US_WEST_2;

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		//AmazonEc2Client Instance is ready to work
		
		BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
		AWSCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(credentials);
		AmazonEC2 amazonEC2 = AmazonEC2ClientBuilder.standard().withCredentials(credentialsProvider).withRegion(regions).build();
		
		List<String> instanceIds = new ArrayList<String>();
		instanceIds.add("i-9321e99e");
		
		DescribeInstancesRequest describeInstancesRequest = new DescribeInstancesRequest();
		describeInstancesRequest.setInstanceIds(instanceIds);
		
		
		//Running Instance
		DescribeInstancesResult describeInstancesResult = amazonEC2.describeInstances(describeInstancesRequest);
		
		//Printing Log
		List<Reservation> reservations = describeInstancesResult.getReservations();
		
		
		System.out.println("-----Printing Instance Info-----\n");
		
		for (Reservation reservation : reservations) {
			
			System.out.println("Finded Instance...\n");
			
			System.out.println("Reservation ID: "+reservation.getReservationId());
			System.out.println("Reservation Owner ID: "+reservation.getOwnerId());
			
			for(String grpName: reservation.getGroupNames()){
				System.out.println("Reservation Group Name: "+grpName);
			}
			
			for(GroupIdentifier grpIdentifier: reservation.getGroups()){
				System.out.println("Reservation Group Identifier ID: "+grpIdentifier.getGroupId());
				System.out.println("Reservation Group Identifier Name: "+grpIdentifier.getGroupName());
			}
			
			
			for (Instance instance : reservation.getInstances()) {
				
				System.out.println("\n-----------------Instance-----------------\n");
								
				System.out.println("Instance ID: "+instance.getInstanceId());
				System.out.println("Instance Arch: "+instance.getArchitecture());
				System.out.println("Instance ClientToken: "+instance.getClientToken());
				System.out.println("Instance HyperVisior: "+instance.getHypervisor());
				System.out.println("Instance ImageID: "+instance.getImageId());
				System.out.println("Instance LifeCycle: "+instance.getInstanceLifecycle());
				System.out.println("Instance InstanceType: "+instance.getInstanceType());
				System.out.println("Instance KernelID: "+instance.getKernelId());
				System.out.println("Instance KeyName: "+instance.getKeyName());
				System.out.println("Instance Platform: "+instance.getPlatform());
				System.out.println("Instance Private DNS Name: "+instance.getPrivateDnsName());
				System.out.println("Instance Private IP Address: "+instance.getPrivateIpAddress());
				System.out.println("Instance Public DNS Address: "+instance.getPublicDnsName());
				System.out.println("Instance Public IP Address: "+instance.getPublicIpAddress());
				System.out.println("Instance RAM Disk ID: "+instance.getRamdiskId());
				System.out.println("Instance Root Device Name: "+instance.getRootDeviceName());
				System.out.println("Instance Root Device Type: "+instance.getRootDeviceType());
				System.out.println("Instance Spot Instance Request ID: "+instance.getSpotInstanceRequestId());
				System.out.println("Instance Sriov Net Support: "+instance.getSriovNetSupport());
				System.out.println("Instance State Transition Reason: "+instance.getStateTransitionReason());
				System.out.println("Instance Subnet ID: "+instance.getSubnetId());
				System.out.println("Instance Virtulization Type: "+instance.getVirtualizationType());
				System.out.println("Instance VPC ID: "+instance.getVpcId());
				System.out.println("Instance AMI Launch Index: "+instance.getAmiLaunchIndex());
				
				int i=0;
				for(InstanceBlockDeviceMapping instanceBlockDeviceMapping : instance.getBlockDeviceMappings()){
						System.out.println("Instance Block Device Mapping Name "+i +": "+instanceBlockDeviceMapping.getDeviceName());
						
						EbsInstanceBlockDevice blockDevice = instanceBlockDeviceMapping.getEbs();
						System.out.println("Instance Block Device Status "+i +": "+blockDevice.getStatus());
						System.out.println("Instance Block Device Status "+i +": "+blockDevice.getVolumeId());
						System.out.println("Instance Block Delete On Termination "+i +": "+blockDevice.getDeleteOnTermination());
						System.out.println("Instance Block Attach Time "+i +": "+blockDevice.getAttachTime());
						
						i++;
				}
				
				System.out.println("Instance EBS Optimized: "+instance.getEbsOptimized());
				System.out.println("Instance IAM Instance Profile: "+instance.getIamInstanceProfile());
				System.out.println("Instance Launch Time: "+instance.getLaunchTime());
				System.out.println("Instance Monitoring: "+instance.getMonitoring());
				
				i=0;
				for(InstanceNetworkInterface networkInterface : instance.getNetworkInterfaces()){
					System.out.println("Instance Network Interface Description "+i +": "+networkInterface.getDescription());
					System.out.println("Instance Network Interface MAC Address "+i +": "+networkInterface.getMacAddress());
					System.out.println("Instance Network Interface ID "+i +": "+networkInterface.getNetworkInterfaceId());
					System.out.println("Instance Network Interface Owner ID "+i +": "+networkInterface.getOwnerId());
					System.out.println("Instance Network Interface Private DNS Name "+i +": "+networkInterface.getPrivateDnsName());
					System.out.println("Instance Network Interface Private IP Address "+i +": "+networkInterface.getPrivateIpAddress());
					System.out.println("Instance Network Interface Status "+i +": "+networkInterface.getStatus());
					System.out.println("Instance Network Interface Subnet ID "+i +": "+networkInterface.getSubnetId());
					System.out.println("Instance Network Interface VPC ID "+i +": "+networkInterface.getVpcId());
					
					if(networkInterface.getAssociation() !=null){
						System.out.println("Instance Network Interface IP Owner ID "+i +": "+networkInterface.getAssociation().getIpOwnerId());
						System.out.println("Instance Network Interface Public DNS Name "+i +": "+networkInterface.getAssociation().getPublicDnsName());
						System.out.println("Instance Network Interface Public IP "+i +": "+networkInterface.getAssociation().getPublicIp());
						System.out.println("Instance Network Interface Attachment ID "+i +": "+networkInterface.getAttachment().getAttachmentId());
					}
					
					System.out.println("Instance Network Interface Attachment Status "+i +": "+networkInterface.getAttachment().getStatus());
					System.out.println("Instance Network Interface Attachment Device Index "+i +": "+networkInterface.getAttachment().getDeviceIndex());
					System.out.println("Instance Network Interface Attachment Time "+i +": "+networkInterface.getAttachment().getAttachTime());
					System.out.println("Instance Network Interface Attachment Deletion On Termination "+i +": "+networkInterface.getAttachment().getDeleteOnTermination());
					
					i++;
				}
				
				System.out.println("Instance Placement: "+instance.getPlacement());
				
				i=0;
				for(ProductCode productCode : instance.getProductCodes()){
					System.out.println("Instance Product Code ID "+i +": "+productCode.getProductCodeId());
					System.out.println("Instance Product Code Type "+i +": "+productCode.getProductCodeType());
					
					i++;
				}
				
				i=0;
				for(GroupIdentifier groupIdentifier : instance.getSecurityGroups()){
					System.out.println("Instance Security Groups ID "+i +": "+groupIdentifier.getGroupId());
					System.out.println("Instance Security Groups Name "+i +": "+groupIdentifier.getGroupName());
					
					i++;
				}
				
				System.out.println("Instance Source Destination Check: "+instance.getSourceDestCheck());
				System.out.println("Instance State: "+instance.getState().getName());
				System.out.println("Instance State Reason: "+instance.getStateReason());
				
				i=0;
				for(Tag tag : instance.getTags()){
					System.out.println("Instance Tag Key "+i +": "+tag.getKey());
					System.out.println("Instance Tag Value at key "+i +": "+tag.getValue());
					
					i++;
				}
				
				System.out.println("\n**************Instance**************\n");
			}
		}
		
	}
	
	
}
