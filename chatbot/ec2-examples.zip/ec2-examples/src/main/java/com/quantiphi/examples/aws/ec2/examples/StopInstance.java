package com.quantiphi.examples.aws.ec2.examples;


import java.util.ArrayList;
import java.util.List;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.InstanceStateChange;
import com.amazonaws.services.ec2.model.StopInstancesRequest;
import com.amazonaws.services.ec2.model.StopInstancesResult;


public class StopInstance {

	private static String secretKey = "";
	private static String accessKey = "";
	private static Regions regions = Regions.US_WEST_2;
	
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		//AmazonEc2Client Instance is ready to work
		
		BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
		AWSCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(credentials);
		AmazonEC2 amazonEC2 = AmazonEC2ClientBuilder.standard().withCredentials(credentialsProvider).withRegion(regions).build();
		
		List<String> instanceIds = new ArrayList<String>();
		instanceIds.add("i-9321e99e");
		
		StopInstancesRequest stopInstanceRequest = new StopInstancesRequest();
		stopInstanceRequest.setInstanceIds(instanceIds);
		
		//Running Instance
		StopInstancesResult stopInstancesResult = amazonEC2.stopInstances(stopInstanceRequest);
		
		//Printing Log
		for (InstanceStateChange instanceStateChange : stopInstancesResult.getStoppingInstances()) {
			
			System.out.println("Instance: "+instanceStateChange.getInstanceId());
			System.out.println("Instance current State: "+instanceStateChange.getCurrentState());
			System.out.println("Instance previous state: "+instanceStateChange.getPreviousState());
		}
		
	}
	
	
}
