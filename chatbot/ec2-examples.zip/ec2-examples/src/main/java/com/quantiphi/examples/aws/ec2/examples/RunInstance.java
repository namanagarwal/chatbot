package com.quantiphi.examples.aws.ec2.examples;


import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceType;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.RunInstancesResult;
import com.amazonaws.services.ec2.model.ShutdownBehavior;


public class RunInstance {

	
	private static String secretKey = "";
	private static String accessKey = "";
	private static Regions regions = Regions.US_WEST_2;

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		//AmazonEc2Client Instance is ready to work
		
		BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
		AWSCredentialsProvider credentialsProvider = new AWSStaticCredentialsProvider(credentials);
		AmazonEC2 amazonEC2 = AmazonEC2ClientBuilder.standard().withCredentials(credentialsProvider).withRegion(regions).build();
		
		
		RunInstancesRequest runInstancesRequest = new RunInstancesRequest();
		
		runInstancesRequest.setImageId("ami-5189a661");
		runInstancesRequest.setMinCount(1); // "instance-minimum-count"
		runInstancesRequest.setMaxCount(1); // "instance-maximnum-count"
		
		runInstancesRequest.setInstanceType(InstanceType.T2Micro); // Instance type
		
		runInstancesRequest.setInstanceInitiatedShutdownBehavior(ShutdownBehavior.Terminate); //Instance shutdown behaviour
		runInstancesRequest.setMonitoring(false); //Instance monitoring
		runInstancesRequest.setAdditionalInfo("My First Instance");
			
		runInstancesRequest.setKeyName(new com.amazonaws.services.ec2.model.KeyPair().getKeyName()); ////Instance keypair
		
		System.out.println("Instance Creation in progress."); 
		
		//Running Instance
		RunInstancesResult instancesResult = amazonEC2.runInstances(runInstancesRequest);
		
		//Printing Log
		Reservation reservation = instancesResult.getReservation();
		
		for (Instance instance : reservation.getInstances()) {
			System.out.println("Instance: "+instance.getInstanceId());
		}
		
	}
	
	
}
